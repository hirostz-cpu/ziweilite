# Build APK via GitHub Actions (Tanpa Android Studio)

## Cara pakai (langsung dari HP Android bisa)
1. Buat repo GitHub baru (public/private bebas). Branch: `main`.
2. Upload **seluruh folder** ini ke repo (pakai GitHub App atau mobile web).
3. Buka tab **Actions** → workflow **Android APK (Debug, no-wrapper)** → Run.
4. Setelah sukses, ambil **Artifacts → ZiweiLite-debug-apk → app-debug.apk**.

## Kenapa workflow ini beda?
- Tidak perlu `gradlew` (Gradle Wrapper). Workflow **menginstall Gradle 8.7** via SDKMAN.
- Android SDK di-setup otomatis lewat `android-actions/setup-android@v3`.

## Struktur
```
settings.gradle
build.gradle
app/
  build.gradle
  proguard-rules.pro
  src/main/AndroidManifest.xml
  src/main/java/com/example/ziweilite/MainActivity.java
  src/main/res/layout/activity_main.xml
  src/main/assets/ziwei.html
.github/workflows/build-apk.yml
```
